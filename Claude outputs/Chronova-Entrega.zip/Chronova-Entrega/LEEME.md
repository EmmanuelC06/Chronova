# Chronova — material para presentar

Todo lo presentable del proyecto, al 3 de septiembre de 2026.

Emmanuel Correa Valencia · Julián Andrés Herrera Roncancio
Universidad Católica Luis Amigó — Medellín

---

## Qué hay en cada carpeta

### 1 · Documento de requerimientos

`Chronova-Requerimientos.docx` — **el entregable principal.** Los 34 requerimientos
funcionales y los 25 no funcionales, cada uno con su criterio de verificación y la
tabla de trazabilidad que los conecta con el archivo que los implementa y la prueba
que los comprueba.

Se genera con `docs/generar-requerimientos.js`. Si cambia algo del proyecto, se
edita ese archivo y se vuelve a correr `node generar-requerimientos.js` — no se
edita el `.docx` a mano, o la próxima regeneración borra el cambio.

### 2 · Diagramas UML

Los ocho diagramas en tres formatos:

- **PNG** para pegar en Word (*Insertar → Imagen → Este dispositivo*, no arrastrar).
- **SVG** para imprimir o proyectar sin que se pixele.
- **Fuentes editables** (`.puml`), texto plano que se puede versionar y editar.

> **Antes de presentarlos, leer esto.** Tres de los ocho están **incompletos**. Lo
> que dibujan es cierto, pero les falta funcionalidad que ya existe en el código:
>
> | Diagrama | Qué le falta |
> |---|---|
> | 01 Casos de uso — Paciente | Recuperar la contraseña |
> | 02 Casos de uso — Cuidador | Gestionar medicamentos del paciente; recuperar la contraseña |
> | 07 Componentes | `Dispositivo` y `SolicitudDeRecuperacion`; los puertos de correo y de códigos |
>
> Los otros cinco están al día. El detalle completo está en `DIAGRAMAS.pdf`.

### 3 · Documentación técnica (PDF)

Los nueve documentos del proyecto, maquetados con la tipografía y la paleta de la
propia aplicación. Listos para imprimir o adjuntar.

| Documento | Para qué sirve |
|---|---|
| `README.pdf` | Visión general: qué es Chronova y en qué estado está |
| `ARQUITECTURA.pdf` | Qué es la arquitectura hexagonal y por qué se eligió. **El más útil para la sustentación** |
| `API.pdf` | Los 23 endpoints, con sus formatos y sus reglas de acceso |
| `GUIA-DE-INICIO.pdf` | Cómo levantar el proyecto desde cero |
| `DEL-MVP-A-CHRONOVA.pdf` | Qué cambió respecto al MVP anterior y por qué |
| `REVISION-DE-CODIGO.pdf` | La revisión completa: cada defecto reproducido ejecutándolo, no deducido leyendo |
| `DESPLIEGUE.pdf` | Cómo poner la app en manos de los evaluadores, con costos y fechas |
| `FLUJO-DE-TRABAJO-CON-CLAUDE.pdf` | Cómo se trabajó el proyecto |
| `DIAGRAMAS.pdf` | Qué muestra cada diagrama y cómo regenerarlos |

### 4 · Documentación técnica (Markdown)

Los mismos documentos en su formato original, por si hay que editarlos o citarlos.

---

## Lo que conviene tener preparado

Tres preguntas que un jurado hace casi siempre, y dónde está la respuesta:

**«¿Dónde está esto en el código?»** — La tabla de trazabilidad del documento de
requerimientos conecta cada RF con su archivo y su prueba.

**«¿Cómo sabes que funciona?»** — 146 pruebas automatizadas que corren en menos de
dos segundos, sin base de datos ni servidor, y que dan el mismo resultado bajo seis
zonas horarias distintas, de Kiritimati (UTC+14) a Anchorage (UTC−9).

**«¿Por qué esta arquitectura y no otra?»** — `ARQUITECTURA.pdf` lo responde con
cinco pruebas comprobables, no con teoría. La más contundente: la aplicación entera
funciona con `PERSISTENCE=memory`, sin ninguna base de datos, porque el dominio
nunca supo que existía PostgreSQL.

Y una cuarta, que es la que distingue un proyecto honesto: **«¿qué falta?»** La
respuesta está en `REVISION-DE-CODIGO.pdf`, que lista los defectos encontrados,
cuáles se corrigieron y los dos que siguen abiertos a propósito — los de seguridad,
que solo importan cuando el servidor esté en internet.
