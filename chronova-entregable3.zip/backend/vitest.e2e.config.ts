import { defineConfig } from 'vitest/config';

/**
 * Configuracion aparte para las pruebas de extremo a extremo.
 *
 * No se mezclan con `npm test` porque necesitan dos cosas encendidas que
 * las demas no: el servidor corriendo en otro proceso y una base de datos
 * PostgreSQL de verdad. Si `npm test` las incluyera, el proyecto dejaria
 * de poder probarse en una maquina recien clonada.
 *
 * `fileParallelism: false` porque los cuatro recorridos escriben en la
 * misma base: en paralelo se pisarian entre ellos y el resultado
 * dependeria del orden, que es justo lo que una prueba no puede hacer.
 */
export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/e2e/**/*.test.ts'],
    fileParallelism: false,
    testTimeout: 30_000,
    hookTimeout: 30_000,
  },
});
