/**
 * Medicion de rendimiento de la API.
 *
 * No es una prueba: no falla ni pasa, imprime numeros. Se ejecuta contra
 * el servidor y la base de datos ya levantados, igual que las pruebas de
 * extremo a extremo.
 *
 *   npm run rendimiento
 *
 * Que se mide y por que estos cuatro:
 *
 *  - `POST /api/auth/sesion` es, por diseno, el endpoint mas lento de
 *    todos: bcrypt esta calibrado para tardar. Sirve para comprobar que
 *    tarda lo que tiene que tardar y no mas.
 *  - `GET /api/tomas/agenda` es la peticion que mas trabajo hace y la que
 *    la aplicacion lanza en cada arranque: lee los medicamentos, lee las
 *    tomas del dia, calcula cuales faltan, las inserta si hace falta y
 *    resume la adherencia.
 *  - `POST /api/tomas/{id}/registro` es la escritura del camino critico:
 *    es lo que ocurre cuando la persona toca "Ya la tome".
 *  - `GET /api/cuidadores/pacientes` es el que mas puede degradarse al
 *    crecer, porque recorre todos los pacientes de un cuidador.
 *
 * Se reportan percentiles y no la media. La media esconde justo lo que
 * importa: si una de cada veinte peticiones tarda tres segundos, la media
 * apenas se mueve y la persona si lo nota.
 */

const BASE = process.env.E2E_URL ?? 'http://localhost:4100';
const marca = Date.now();

interface Medicion {
  escenario: string;
  peticiones: number;
  simultaneas: number;
  p50: number;
  p95: number;
  p99: number;
  maximo: number;
  porSegundo: number;
  errores: number;
}

async function peticion(metodo: string, ruta: string, opciones: { cuerpo?: unknown; token?: string } = {}) {
  const cabeceras: Record<string, string> = { 'Content-Type': 'application/json' };
  if (opciones.token) cabeceras.Authorization = `Bearer ${opciones.token}`;
  const respuesta = await fetch(BASE + ruta, {
    method: metodo,
    headers: cabeceras,
    body: opciones.cuerpo === undefined ? undefined : JSON.stringify(opciones.cuerpo),
  });
  const texto = await respuesta.text();
  return { estado: respuesta.status, cuerpo: texto ? JSON.parse(texto) : null };
}

function percentil(ordenados: number[], p: number): number {
  if (!ordenados.length) return 0;
  const indice = Math.min(ordenados.length - 1, Math.ceil((p / 100) * ordenados.length) - 1);
  return ordenados[Math.max(0, indice)] ?? 0;
}

/**
 * Lanza `total` peticiones manteniendo `simultaneas` en vuelo.
 *
 * No se lanzan todas de golpe: eso mide la capacidad de encolar de Node,
 * no la del servidor. Con una ventana fija se mide lo que de verdad
 * interesa, que es cuanto tarda cada peticion cuando hay otras N
 * ocurriendo a la vez.
 */
async function medir(
  escenario: string,
  total: number,
  simultaneas: number,
  hacer: (i: number) => Promise<{ estado: number }>,
  calentar = true,
): Promise<Medicion> {
  // Calentamiento: las primeras peticiones pagan la compilacion del
  // codigo y la apertura de las conexiones al pool, y no representan el
  // estado normal.
  //
  // No se calienta cuando el escenario escribe: la primera version de
  // este archivo omitia diez tomas durante el calentamiento y luego
  // medía omitir esas mismas, que ya estaban resueltas. Salian nueve
  // errores y 2,3 ms de "tiempo de respuesta", que era lo que tarda el
  // servidor en decir que no. Un numero rapido y mentiroso.
  if (calentar) {
    await Promise.all(Array.from({ length: Math.min(10, total) }, (_, i) => hacer(i)));
  }

  const tiempos: number[] = [];
  let errores = 0;
  let siguiente = 0;
  const comienzo = performance.now();

  async function trabajador() {
    for (;;) {
      const i = siguiente++;
      if (i >= total) return;
      const t0 = performance.now();
      try {
        const { estado } = await hacer(i);
        if (estado >= 400) errores += 1;
      } catch {
        errores += 1;
      }
      tiempos.push(performance.now() - t0);
    }
  }

  await Promise.all(Array.from({ length: simultaneas }, trabajador));
  const duracion = (performance.now() - comienzo) / 1000;
  const ordenados = [...tiempos].sort((a, b) => a - b);

  return {
    escenario,
    peticiones: total,
    simultaneas,
    p50: percentil(ordenados, 50),
    p95: percentil(ordenados, 95),
    p99: percentil(ordenados, 99),
    maximo: ordenados[ordenados.length - 1] ?? 0,
    porSegundo: total / duracion,
    errores,
  };
}

function fila(m: Medicion): string {
  const n = (x: number) => x.toFixed(1).padStart(8);
  return (
    `  ${m.escenario.padEnd(42)}` +
    `${String(m.peticiones).padStart(6)}` +
    `${String(m.simultaneas).padStart(7)}` +
    `${n(m.p50)}${n(m.p95)}${n(m.p99)}${n(m.maximo)}` +
    `${m.porSegundo.toFixed(0).padStart(9)}` +
    `${String(m.errores).padStart(9)}`
  );
}

async function principal() {
  console.log(`\n  Midiendo contra ${BASE}\n`);

  // ---------- preparacion ----------
  const email = `carga.${marca}@prueba.test`;
  const registro = await peticion('POST', '/api/auth/registro/paciente', {
    cuerpo: {
      nombre: 'Rosa Valencia',
      email,
      contrasena: 'ClaveSegura123',
      zonaHoraria: 'America/Bogota',
      aceptaPoliticaDeDatos: true,
    },
  });
  const token = registro.cuerpo.token as string;
  const pacienteId = registro.cuerpo.usuario.id as string;

  const hoy = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Bogota',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());

  // Tres medicamentos con tres horarios: nueve tomas al dia, que es un
  // tratamiento cargado pero realista en un adulto mayor pluripatologico.
  for (const nombre of ['Losartán', 'Metformina', 'Atorvastatina']) {
    await peticion('POST', '/api/medicamentos', {
      token,
      cuerpo: {
        nombre,
        dosis: { cantidad: 1, unidad: 'tableta' },
        frecuencia: { tipo: 'DIARIA' },
        horarios: ['07:00', '13:00', '19:00'],
        fechaInicio: hoy,
        stock: { unidadesDisponibles: 90, umbralDeAlerta: 10 },
      },
    });
  }

  const cuidador = await peticion('POST', '/api/auth/registro/cuidador', {
    cuerpo: {
      nombre: 'Ana Correa',
      email: `carga.cuidadora.${marca}@prueba.test`,
      contrasena: 'ClaveSegura123',
      aceptaPoliticaDeDatos: true,
    },
  });
  const tokenCuidadora = cuidador.cuerpo.token as string;

  // Diez pacientes vinculados: el panel del cuidador es lo que mas
  // trabajo hace por peticion cuando la lista crece.
  const PACIENTES_DEL_PANEL = 10;
  for (let i = 0; i < PACIENTES_DEL_PANEL; i += 1) {
    const otro = await peticion('POST', '/api/auth/registro/paciente', {
      cuerpo: {
        nombre: `Paciente ${i}`,
        email: `carga.p${i}.${marca}@prueba.test`,
        contrasena: 'ClaveSegura123',
        zonaHoraria: 'America/Bogota',
        aceptaPoliticaDeDatos: true,
      },
    });
    await peticion('POST', '/api/medicamentos', {
      token: otro.cuerpo.token,
      cuerpo: {
        nombre: 'Enalapril',
        dosis: { cantidad: 1, unidad: 'tableta' },
        frecuencia: { tipo: 'DIARIA' },
        horarios: ['08:00', '20:00'],
        fechaInicio: hoy,
      },
    });
    const vinculo = await peticion('POST', '/api/vinculos', {
      token: tokenCuidadora,
      cuerpo: { emailDeLaOtraParte: `carga.p${i}.${marca}@prueba.test` },
    });
    await peticion('POST', `/api/vinculos/${vinculo.cuerpo.id}/respuesta`, {
      token: otro.cuerpo.token,
      cuerpo: { respuesta: 'ACEPTAR' },
    });
  }

  // Una bolsa grande de tomas pendientes, en una cuenta aparte, para
  // medir la escritura sin que cada peticion tropiece con la anterior.
  const escritor = await peticion('POST', '/api/auth/registro/paciente', {
    cuerpo: {
      nombre: 'Paciente de escritura',
      email: `carga.w.${marca}@prueba.test`,
      contrasena: 'ClaveSegura123',
      zonaHoraria: 'America/Bogota',
      aceptaPoliticaDeDatos: true,
    },
  });
  const tokenEscritor = escritor.cuerpo.token as string;
  const HORARIOS = ['06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00'];
  for (let i = 0; i < 8; i += 1) {
    await peticion('POST', '/api/medicamentos', {
      token: tokenEscritor,
      cuerpo: {
        nombre: `Medicamento ${i}`,
        dosis: { cantidad: 1, unidad: 'tableta' },
        frecuencia: { tipo: 'DIARIA' },
        horarios: HORARIOS,
        fechaInicio: hoy,
        stock: { unidadesDisponibles: 200, umbralDeAlerta: 5 },
      },
    });
  }
  const agenda = await peticion('GET', `/api/tomas/agenda?fecha=${hoy}`, { token: tokenEscritor });
  const pendientes: string[] = (agenda.cuerpo.elementos as any[])
    .filter((e) => e.estado === 'PENDIENTE')
    .map((e) => e.tomaId);

  // ---------- escenarios ----------
  console.log(
    '  escenario'.padEnd(44) +
      'pets.'.padStart(6) +
      'simul.'.padStart(7) +
      'p50'.padStart(8) +
      'p95'.padStart(8) +
      'p99'.padStart(8) +
      'max'.padStart(8) +
      'pet/s'.padStart(9) +
      'errores'.padStart(9),
  );
  console.log('  ' + '-'.repeat(105));

  const resultados: Medicion[] = [];

  resultados.push(
    await medir('GET /api/salud', 400, 20, () => peticion('GET', '/api/salud')),
  );

  resultados.push(
    await medir('POST /api/auth/sesion (bcrypt)', 60, 6, () =>
      peticion('POST', '/api/auth/sesion', {
        cuerpo: { email, contrasena: 'ClaveSegura123', tipo: 'PACIENTE' },
      }),
    ),
  );

  resultados.push(
    await medir('GET /api/tomas/agenda (9 tomas)', 300, 20, () =>
      peticion('GET', `/api/tomas/agenda?fecha=${hoy}`, { token }),
    ),
  );

  resultados.push(
    await medir(`GET /api/cuidadores/pacientes (${PACIENTES_DEL_PANEL})`, 200, 20, () =>
      peticion('GET', '/api/cuidadores/pacientes', { token: tokenCuidadora }),
    ),
  );

  resultados.push(
    await medir('GET /api/medicamentos', 300, 20, () =>
      peticion('GET', '/api/medicamentos', { token }),
    ),
  );

  resultados.push(
    await medir(
      'GET /api/tomas/historial (30 días)',
      200,
      20,
      () =>
        peticion('GET', `/api/tomas/historial?desde=${hace(hoy, 30)}&hasta=${hoy}`, { token }),
    ),
  );

  if (pendientes.length) {
    resultados.push(
      await medir(
        'POST /api/tomas/{id}/registro (escritura)',
        pendientes.length,
        10,
        (i) =>
          peticion('POST', `/api/tomas/${pendientes[i]}/registro`, {
            token: tokenEscritor,
            cuerpo: { accion: 'OMITIR' },
          }),
        false,
      ),
    );
  }

  for (const r of resultados) console.log(fila(r));

  console.log('\n  Todos los tiempos en milisegundos. p95 = el 95% de las peticiones');
  console.log('  tardó eso o menos.\n');
}

function hace(fecha: string, dias: number): string {
  const d = new Date(`${fecha}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - dias);
  return d.toISOString().slice(0, 10);
}

principal().catch((error) => {
  console.error(error);
  process.exit(1);
});
