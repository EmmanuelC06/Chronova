import { readFileSync } from 'node:fs';
import pg from 'pg';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

/**
 * Pruebas de extremo a extremo.
 *
 * Se diferencian de las otras 194 en que aqui NO hay ningun doble. Las de
 * dominio y casos de uso llaman a las clases directamente y usan
 * repositorios en memoria; las de `tests/http/` levantan la API pero
 * sobre esa misma memoria. Estas, en cambio, hablan por HTTP con un
 * servidor que ya esta corriendo en otro proceso, contra un PostgreSQL de
 * verdad, y al final comprueban las filas mirando la base de datos
 * directamente.
 *
 * Lo que solo se puede ver asi:
 *
 *  - Que el esquema SQL y las entidades encajan. Un repositorio en
 *    memoria acepta cualquier objeto; una tabla con una columna que falta,
 *    no. Ese fue exactamente el fallo que hizo que el tamano de letra no
 *    se guardara: la columna sesiones_validas_desde no existia todavia.
 *  - Que los tipos de PostgreSQL van y vuelven bien: TIMESTAMPTZ, JSONB,
 *    SMALLINT[] y TEXT[].
 *  - Que la concurrencia real sobre la misma fila se resuelve, que es
 *    algo que un Map de JavaScript nunca reproduce.
 *
 * Como se ejecutan:
 *
 *   createdb chronova_e2e
 *   PERSISTENCE=postgres DATABASE_URL=... JWT_SECRET=... PORT=4100 \
 *     npx tsx src/main.ts > /tmp/servidor.log &
 *   E2E_URL=http://localhost:4100 E2E_LOG=/tmp/servidor.log \
 *     DATABASE_URL=... npm run test:e2e
 */

const BASE = process.env.E2E_URL ?? 'http://localhost:4100';
const REGISTRO = process.env.E2E_LOG ?? '/tmp/servidor.log';
const URL_BD = process.env.DATABASE_URL ?? '';

let bd: pg.Pool;
const marca = Date.now();

beforeAll(async () => {
  bd = new pg.Pool({ connectionString: URL_BD });
  const salud = await peticion('GET', '/api/salud');
  if (salud.estado !== 200 || salud.cuerpo?.persistencia !== 'postgres') {
    throw new Error(
      `El servidor de ${BASE} no responde o no esta usando PostgreSQL. ` +
        'Estas pruebas necesitan el sistema completo levantado.',
    );
  }
});

afterAll(async () => {
  await bd.end();
});

// ------------------------------------------------------------------
//  Utilidades
// ------------------------------------------------------------------

async function peticion(
  metodo: string,
  ruta: string,
  opciones: { cuerpo?: unknown; token?: string } = {},
): Promise<{ estado: number; cuerpo: any }> {
  const cabeceras: Record<string, string> = { 'Content-Type': 'application/json' };
  if (opciones.token) cabeceras.Authorization = `Bearer ${opciones.token}`;
  const respuesta = await fetch(BASE + ruta, {
    method: metodo,
    headers: cabeceras,
    body: opciones.cuerpo === undefined ? undefined : JSON.stringify(opciones.cuerpo),
  });
  const texto = await respuesta.text();
  let cuerpo: unknown = texto;
  try {
    cuerpo = texto === '' ? null : JSON.parse(texto);
  } catch {
    /* se deja el texto */
  }
  return { estado: respuesta.status, cuerpo };
}

const ZONA = 'America/Bogota';

/** La fecha de HOY donde vive la paciente, no donde esta el servidor. */
function hoyEnBogota(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: ZONA,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

/** Una hora de pared de Bogota, desplazada `minutos` desde ahora. */
function horaDeBogota(minutos: number): string {
  const partes = new Intl.DateTimeFormat('en-GB', {
    timeZone: ZONA,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(Date.now() + minutos * 60_000));
  return partes;
}

function correo(quien: string): string {
  return `${quien}.${marca}@prueba.test`;
}

async function registrarPaciente(quien = 'rosa') {
  const { estado, cuerpo } = await peticion('POST', '/api/auth/registro/paciente', {
    cuerpo: {
      nombre: 'Rosa Valencia',
      email: correo(quien),
      contrasena: 'ClaveSegura123',
      zonaHoraria: ZONA,
      fechaDeNacimiento: '1948-03-11',
      aceptaPoliticaDeDatos: true,
    },
  });
  expect(estado, JSON.stringify(cuerpo)).toBe(201);
  return { token: cuerpo.token as string, id: cuerpo.usuario.id as string, email: correo(quien) };
}

async function registrarCuidador(quien = 'ana') {
  const { estado, cuerpo } = await peticion('POST', '/api/auth/registro/cuidador', {
    cuerpo: {
      nombre: 'Ana Correa',
      email: correo(quien),
      contrasena: 'ClaveSegura123',
      aceptaPoliticaDeDatos: true,
    },
  });
  expect(estado, JSON.stringify(cuerpo)).toBe(201);
  return { token: cuerpo.token as string, id: cuerpo.usuario.id as string, email: correo(quien) };
}

// ==================================================================
//  E2E-01
// ==================================================================

describe('E2E-01 · La paciente registra su tratamiento y confirma una toma', () => {
  it('recorre registro, medicamento, agenda, confirmacion, inventario e historial', async () => {
    // --- 1. se registra ---
    const rosa = await registrarPaciente('e2e01');

    // --- 2. el token sirve para entrar a su perfil ---
    const perfil = await peticion('GET', '/api/auth/perfil', { token: rosa.token });
    expect(perfil.estado).toBe(200);
    expect(perfil.cuerpo.email).toBe(rosa.email);
    expect(perfil.cuerpo.zonaHoraria).toBe(ZONA);
    expect(perfil.cuerpo.autorizacionDeDatos.consta).toBe(true);

    // --- 3. registra un medicamento con dos horas que YA pasaron hoy ---
    const primera = horaDeBogota(-120);
    const segunda = horaDeBogota(-60);
    const alta = await peticion('POST', '/api/medicamentos', {
      token: rosa.token,
      cuerpo: {
        nombre: 'Losartán',
        dosis: { cantidad: 1, unidad: 'tableta' },
        frecuencia: { tipo: 'DIARIA' },
        horarios: [primera, segunda],
        fechaInicio: hoyEnBogota(),
        instrucciones: 'Con el desayuno',
        stock: { unidadesDisponibles: 30, umbralDeAlerta: 5 },
      },
    });
    expect(alta.estado, JSON.stringify(alta.cuerpo)).toBe(201);
    const medicamentoId = alta.cuerpo.id as string;

    // --- 4. la agenda del dia se genera sola, con una toma por horario ---
    const agenda = await peticion('GET', `/api/tomas/agenda?fecha=${hoyEnBogota()}`, {
      token: rosa.token,
    });
    expect(agenda.estado, JSON.stringify(agenda.cuerpo)).toBe(200);
    const elementos = agenda.cuerpo.elementos as any[];
    expect(elementos).toHaveLength(2);
    expect(elementos.every((e) => e.estado === 'PENDIENTE')).toBe(true);

    // --- 5. confirma la primera ---
    const tomaId = elementos[0].tomaId as string;
    const registro = await peticion('POST', `/api/tomas/${tomaId}/registro`, {
      token: rosa.token,
      cuerpo: { accion: 'CONFIRMAR' },
    });
    expect(registro.estado, JSON.stringify(registro.cuerpo)).toBe(200);
    expect(registro.cuerpo.toma.estado).toBe('TOMADA');

    // --- 6. la agenda ya lo refleja, y el resumen tambien ---
    const despues = await peticion('GET', `/api/tomas/agenda?fecha=${hoyEnBogota()}`, {
      token: rosa.token,
    });
    const confirmada = (despues.cuerpo.elementos as any[]).find((e) => e.tomaId === tomaId);
    expect(confirmada.estado).toBe('TOMADA');
    expect(despues.cuerpo.resumen.tomadas).toBe(1);

    // --- 7. el inventario bajo exactamente una unidad ---
    const lista = await peticion('GET', '/api/medicamentos', { token: rosa.token });
    const medicamento = (lista.cuerpo.medicamentos as any[]).find((m) => m.id === medicamentoId);
    expect(medicamento.stock.unidadesDisponibles).toBe(29);

    // --- 8. y aparece en el historial ---
    const historial = await peticion(
      'GET',
      `/api/tomas/historial?desde=${hoyEnBogota()}&hasta=${hoyEnBogota()}`,
      { token: rosa.token },
    );
    expect(historial.estado, JSON.stringify(historial.cuerpo)).toBe(200);
    expect(historial.cuerpo.resumen.tomadas).toBe(1);

    // --- 9. y todo eso quedo escrito en PostgreSQL, no solo en la respuesta ---
    const filas = await bd.query(
      `SELECT t.estado, t.origen_del_registro, m.stock_unidades, m.horarios
         FROM tomas t JOIN medicamentos m ON m.id = t.medicamento_id
        WHERE t.id = $1`,
      [tomaId],
    );
    expect(filas.rowCount).toBe(1);
    expect(filas.rows[0].estado).toBe('TOMADA');
    expect(filas.rows[0].origen_del_registro).toBe('PACIENTE');
    expect(filas.rows[0].stock_unidades).toBe(29);
    // El array de PostgreSQL vuelve como array de JavaScript.
    expect(filas.rows[0].horarios).toEqual([primera, segunda]);
  });
});

// ==================================================================
//  E2E-02
// ==================================================================

describe('E2E-02 · El cuidador acompaña, y los permisos mandan', () => {
  it('recorre solicitud, aceptación, panel, permiso denegado, permiso concedido y revocación', async () => {
    const rosa = await registrarPaciente('e2e02p');
    const ana = await registrarCuidador('e2e02c');

    // La paciente tiene un medicamento con una toma ya vencida de hora.
    await peticion('POST', '/api/medicamentos', {
      token: rosa.token,
      cuerpo: {
        nombre: 'Metformina',
        dosis: { cantidad: 1, unidad: 'tableta' },
        frecuencia: { tipo: 'DIARIA' },
        horarios: [horaDeBogota(-90)],
        fechaInicio: hoyEnBogota(),
        stock: { unidadesDisponibles: 10, umbralDeAlerta: 3 },
      },
    });

    // --- 1. la cuidadora pide acceso ---
    const solicitud = await peticion('POST', '/api/vinculos', {
      token: ana.token,
      cuerpo: { emailDeLaOtraParte: rosa.email, parentesco: 'Hija' },
    });
    expect(solicitud.estado, JSON.stringify(solicitud.cuerpo)).toBe(201);
    const vinculoId = solicitud.cuerpo.id as string;
    expect(solicitud.cuerpo.estado).toBe('PENDIENTE');
    expect(solicitud.cuerpo.permisos.puedeRegistrarTomas).toBe(false);

    // --- 2. mientras esta pendiente, el panel no entrega datos clinicos ---
    const panelPendiente = await peticion('GET', '/api/cuidadores/pacientes', { token: ana.token });
    expect(panelPendiente.estado).toBe(200);
    const antes = (panelPendiente.cuerpo.pacientes as any[]).find((p) => p.pacienteId === rosa.id);
    expect(antes.estadoDelVinculo).toBe('PENDIENTE');
    expect(antes.datosClinicosVisibles).toBe(false);

    // --- 3. la paciente acepta ---
    const respuesta = await peticion('POST', `/api/vinculos/${vinculoId}/respuesta`, {
      token: rosa.token,
      cuerpo: { respuesta: 'ACEPTAR' },
    });
    expect(respuesta.estado, JSON.stringify(respuesta.cuerpo)).toBe(200);

    // --- 4. ahora si ve el seguimiento ---
    const panel = await peticion('GET', '/api/cuidadores/pacientes', { token: ana.token });
    const conAcceso = (panel.cuerpo.pacientes as any[]).find((p) => p.pacienteId === rosa.id);
    expect(conAcceso.estadoDelVinculo).toBe('ACEPTADO');
    expect(conAcceso.datosClinicosVisibles).toBe(true);
    expect(conAcceso.medicamentosActivos).toBe(1);

    // --- 5. pero registrar una toma le esta prohibido por defecto ---
    const agenda = await peticion(
      'GET',
      `/api/tomas/agenda?fecha=${hoyEnBogota()}&pacienteId=${rosa.id}`,
      { token: ana.token },
    );
    expect(agenda.estado, JSON.stringify(agenda.cuerpo)).toBe(200);
    const tomaId = (agenda.cuerpo.elementos as any[])[0].tomaId as string;

    const sinPermiso = await peticion('POST', `/api/tomas/${tomaId}/registro`, {
      token: ana.token,
      cuerpo: { accion: 'CONFIRMAR' },
    });
    expect(sinPermiso.estado).toBe(403);

    // --- 6. la paciente le concede el permiso ---
    const permisos = await peticion('PATCH', `/api/vinculos/${vinculoId}/permisos`, {
      token: rosa.token,
      cuerpo: { puedeRegistrarTomas: true },
    });
    expect(permisos.estado, JSON.stringify(permisos.cuerpo)).toBe(200);

    // --- 7. y ahora si puede, y queda constancia de quien fue ---
    const conPermiso = await peticion('POST', `/api/tomas/${tomaId}/registro`, {
      token: ana.token,
      cuerpo: { accion: 'CONFIRMAR' },
    });
    expect(conPermiso.estado, JSON.stringify(conPermiso.cuerpo)).toBe(200);

    const fila = await bd.query('SELECT origen_del_registro, registrada_por_id FROM tomas WHERE id = $1', [
      tomaId,
    ]);
    expect(fila.rows[0].origen_del_registro).toBe('CUIDADOR');
    expect(fila.rows[0].registrada_por_id).toBe(ana.id);

    // --- 8. la paciente revoca, y el acceso se cierra de verdad ---
    const revocar = await peticion('POST', `/api/vinculos/${vinculoId}/respuesta`, {
      token: rosa.token,
      cuerpo: { respuesta: 'REVOCAR' },
    });
    expect(revocar.estado, JSON.stringify(revocar.cuerpo)).toBe(200);

    const panelRevocado = await peticion('GET', '/api/cuidadores/pacientes', { token: ana.token });
    const despuesDeRevocar = (panelRevocado.cuerpo.pacientes as any[]).find(
      (p) => p.pacienteId === rosa.id,
    );
    expect(despuesDeRevocar?.datosClinicosVisibles ?? false).toBe(false);

    const agendaRevocada = await peticion(
      'GET',
      `/api/tomas/agenda?fecha=${hoyEnBogota()}&pacienteId=${rosa.id}`,
      { token: ana.token },
    );
    expect(agendaRevocada.estado).toBe(403);
  });
});

// ==================================================================
//  E2E-03
// ==================================================================

describe('E2E-03 · Recuperar el acceso con un código', () => {
  it('recorre solicitud, intento fallido, restablecimiento y caída de los tokens anteriores', async () => {
    const rosa = await registrarPaciente('e2e03');
    const tokenViejo = rosa.token;

    // --- 1. pide el codigo ---
    const solicitud = await peticion('POST', '/api/auth/recuperacion', {
      cuerpo: { email: rosa.email, tipo: 'PACIENTE' },
    });
    expect(solicitud.estado, JSON.stringify(solicitud.cuerpo)).toBe(200);

    // El adaptador de correo de desarrollo lo escribe en el registro del
    // servidor. En produccion sale por Resend y aqui no habria nada que leer.
    await new Promise((seguir) => setTimeout(seguir, 400));
    const codigo = ultimoCodigoDelRegistro();
    expect(codigo, 'no se encontró el código en el registro del servidor').toMatch(/^\d{6}$/);

    // --- 2. un codigo equivocado no sirve, y consume intento ---
    const equivocado = await peticion('POST', '/api/auth/recuperacion/confirmar', {
      cuerpo: {
        email: rosa.email,
        codigo: codigo === '000000' ? '111111' : '000000',
        nuevaContrasena: 'OtraClave456',
        tipo: 'PACIENTE',
      },
    });
    expect(equivocado.estado).toBeGreaterThanOrEqual(400);

    const intentos = await bd.query(
      'SELECT intentos FROM recuperaciones WHERE usuario_id = $1 ORDER BY creada_en DESC LIMIT 1',
      [rosa.id],
    );
    expect(Number(intentos.rows[0].intentos)).toBeGreaterThanOrEqual(1);

    // --- 3. el correcto si ---
    const correcto = await peticion('POST', '/api/auth/recuperacion/confirmar', {
      cuerpo: {
        email: rosa.email,
        codigo,
        nuevaContrasena: 'OtraClave456',
        tipo: 'PACIENTE',
      },
    });
    expect(correcto.estado, JSON.stringify(correcto.cuerpo)).toBe(200);

    // --- 4. entra con la contrasena nueva ---
    const sesion = await peticion('POST', '/api/auth/sesion', {
      cuerpo: { email: rosa.email, contrasena: 'OtraClave456', tipo: 'PACIENTE' },
    });
    expect(sesion.estado, JSON.stringify(sesion.cuerpo)).toBe(200);

    // --- 5. y el token de ANTES deja de valer, sin guardar ninguna sesion ---
    const conElViejo = await peticion('GET', '/api/auth/perfil', { token: tokenViejo });
    expect(conElViejo.estado).toBe(401);

    // --- 6. el mismo codigo no se puede volver a usar ---
    const reintento = await peticion('POST', '/api/auth/recuperacion/confirmar', {
      cuerpo: {
        email: rosa.email,
        codigo,
        nuevaContrasena: 'TerceraClave789',
        tipo: 'PACIENTE',
      },
    });
    expect(reintento.estado).toBeGreaterThanOrEqual(400);
  });
});

function ultimoCodigoDelRegistro(): string {
  const texto = readFileSync(REGISTRO, 'utf8');
  const encontrados = [...texto.matchAll(/restablecer la contraseña es:\s+(\d{6})/g)];
  const ultimo = encontrados[encontrados.length - 1];
  return ultimo?.[1] ?? '';
}

// ==================================================================
//  E2E-04
// ==================================================================

describe('E2E-04 · Consultar la agenda muchas veces a la vez no la duplica', () => {
  it('resiste 20 peticiones simultáneas sin crear tomas de más ni devolver errores', async () => {
    const rosa = await registrarPaciente('e2e04');
    const alta = await peticion('POST', '/api/medicamentos', {
      token: rosa.token,
      cuerpo: {
        nombre: 'Enalapril',
        dosis: { cantidad: 1, unidad: 'tableta' },
        frecuencia: { tipo: 'DIARIA' },
        horarios: ['08:00', '14:00', '20:00'],
        fechaInicio: hoyEnBogota(),
      },
    });
    expect(alta.estado, JSON.stringify(alta.cuerpo)).toBe(201);
    const medicamentoId = alta.cuerpo.id as string;

    const SIMULTANEAS = 20;
    const respuestas = await Promise.all(
      Array.from({ length: SIMULTANEAS }, () =>
        peticion('GET', `/api/tomas/agenda?fecha=${hoyEnBogota()}`, { token: rosa.token }),
      ),
    );

    // Ninguna falla...
    expect(respuestas.every((r) => r.estado === 200)).toBe(true);
    // ...todas ven lo mismo...
    const cuantas = new Set(respuestas.map((r) => (r.cuerpo.elementos as any[]).length));
    expect([...cuantas]).toEqual([3]);
    // ...y en la base hay tres filas, no sesenta.
    const filas = await bd.query('SELECT COUNT(*)::int AS n FROM tomas WHERE medicamento_id = $1', [
      medicamentoId,
    ]);
    expect(filas.rows[0].n).toBe(3);
  });
});
